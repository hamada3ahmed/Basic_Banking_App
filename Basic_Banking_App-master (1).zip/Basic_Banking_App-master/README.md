
# Basic Banking App
A simple banking application.

**Basic Banking App** is an android application which uses SQLite to store user accounts data. This app provides feature to simply transact money from one account to another.

*See more features below.*
  
## Featured Images:

<img src="https://user-images.githubusercontent.com/64949957/118172781-616c5000-b44a-11eb-8c5e-0bdc80933e81.jpeg" alt="drawing" width="240" height="470"/> 

<img src="https://user-images.githubusercontent.com/64949957/118173748-9d53e500-b44b-11eb-90a2-3e870a6600d3.jpg" alt="drawing" width="220" height="430"/> <img src="https://user-images.githubusercontent.com/64949957/118173764-a2189900-b44b-11eb-986e-6b16a5f408f7.jpg" alt="drawing" width="220" height="430"/> <img src="https://user-images.githubusercontent.com/64949957/118173782-a5138980-b44b-11eb-9ed1-82708a4d6887.jpg" alt="drawing" width="220" height="430"/> <img src="https://user-images.githubusercontent.com/64949957/118173786-a80e7a00-b44b-11eb-8463-ea9bfd6f272f.jpg" alt="drawing" width="220" height="430"/> <img src="https://user-images.githubusercontent.com/64949957/118173801-aba20100-b44b-11eb-8a7e-547281d939e0.jpg" alt="drawing" width="220" height="430"/> <img src="https://user-images.githubusercontent.com/64949957/118173843-b492d280-b44b-11eb-9d4a-c39c816b644c.jpg" alt="drawing" width="220" height="430"/>
